﻿namespace Utilla.Models
{
    public struct GameModeSelectorPath
    {
        public string name;
        public string transform;
        public string anchorPath;
    }
}
