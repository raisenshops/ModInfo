﻿// using HarmonyLib;

namespace Utilla.HarmonyPatches.Patches
{
    // [HarmonyPatch(typeof(ReparentOnAwake))]
    internal class ReparentObjectPatch
    {
    }
}
